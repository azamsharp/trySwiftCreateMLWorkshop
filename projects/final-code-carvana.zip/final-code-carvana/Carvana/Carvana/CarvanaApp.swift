//
//  CarvanaApp.swift
//  Carvana
//
//  Created by Mohammad Azam on 6/5/23.
//

import SwiftUI

@main
struct CarvanaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
