//
//  ContentView.swift
//  FinancialNews
//
//  Created by Mohammad Azam on 5/31/23.
//

import SwiftUI
import CoreML

struct ContentView: View {
    
    @State private var text: String = ""
    @State private var result = ""
    //let model = try! FinancialNewsSentimentAnalysis(configuration: MLModelConfiguration())
    
    private func getSentimentBackgroundColor(_ sentiment: String) -> Color {
        switch sentiment {
            case "positive":
                return .green
            case "negative":
                return .red
            default:
                return .white
        }
    }
    
    var body: some View {
        VStack {
            Text(result)
                .frame(height: 44)
                .foregroundColor(.white)
                .font(.largeTitle)
            Spacer()
            TextField("Enter text", text: $text)
                .textFieldStyle(.roundedBorder)
            Button("Calculate") {
                do {
                    //result = try model.prediction(text: text).label
                } catch {
                    print(error)
                }
            }
            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(getSentimentBackgroundColor(result))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
