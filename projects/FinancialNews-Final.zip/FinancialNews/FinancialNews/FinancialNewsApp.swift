//
//  FinancialNewsApp.swift
//  FinancialNews
//
//  Created by Mohammad Azam on 5/31/23.
//

import SwiftUI

@main
struct FinancialNewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
