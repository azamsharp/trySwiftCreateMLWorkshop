import csv 
import os 

os.makedirs('positive', exist_ok=True)
os.makedirs('negative', exist_ok=True)
os.makedirs('neutral', exist_ok=True)

with open('all-data.csv') as file: 
  reader = csv.reader(file)
  index = 0 
  for row in reader: 
    sentiment = row[0].strip() 
    text = row[1].strip()

    with open(os.path.join(sentiment, f'{index}.txt'), 'w') as text_file: 
      text_file.write(text)
      index += 1 
