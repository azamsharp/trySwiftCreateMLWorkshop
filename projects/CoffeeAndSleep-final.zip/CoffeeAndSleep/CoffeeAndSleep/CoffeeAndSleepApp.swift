//
//  CoffeeAndSleepApp.swift
//  CoffeeAndSleep
//
//  Created by Mohammad Azam on 8/20/23.
//

import SwiftUI

@main
struct CoffeeAndSleepApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
