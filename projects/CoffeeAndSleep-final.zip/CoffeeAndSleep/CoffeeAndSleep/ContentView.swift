//
//  ContentView.swift
//  CoffeeAndSleep
//
//  Created by Mohammad Azam on 8/20/23.
//

import SwiftUI
import CoreML

struct ContentView: View {
    
    @State private var coffeeCups: Double = 0
    @State private var hoursSleep: Double?
    let model = try! CoffeeAndSleep(configuration: MLModelConfiguration())
    
    var body: some View {
        VStack {
            
            Text("Select the Number of Coffee Cups")
                    .font(.title3)
                    .foregroundColor(.blue)
            Picker("Cups of Coffee", selection: $coffeeCups) {
                ForEach(0...20, id: \.self) { index in
                    HStack {
                        Text("\(index)")
                        Text("☕️")
                    }
                    .tag(Double(index))
                }
            }.pickerStyle(.wheel)
                
            if let hoursSleep {
                Text(String(format: "😴 %.2f hours", hoursSleep))
                    .font(.largeTitle)
            }
            
        }.onChange(of: coffeeCups) { value in
            print(value)
            do {
                let output = try model.prediction(Coffee_Cups: value)
                hoursSleep = output.Sleep_Duration_Hours
                
            } catch {
                print(error.localizedDescription)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
