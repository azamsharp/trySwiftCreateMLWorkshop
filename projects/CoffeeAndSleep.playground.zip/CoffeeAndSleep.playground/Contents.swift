
import Foundation
import TabularData
import CreateML

let fileURL = Bundle.main.url(forResource: "sleep", withExtension: "csv")!
let options = CSVReadingOptions(hasHeaderRow: true, delimiter: ",")

let dataFrame = try DataFrame(contentsOfCSVFile: fileURL, options: options)

let regressor = try MLRegressor(trainingData: dataFrame, targetColumn: "Sleep_Duration_Hours")

let metaData = MLModelMetadata(author: "Mohammad Azam", shortDescription: "Coffee & Sleep Model", license: nil, version: "1.0", additional: nil)

try regressor.write(toFile: "/Users/azamsharp/Desktop/CoffeeAndSleep.mlmodel", metadata: metaData)


