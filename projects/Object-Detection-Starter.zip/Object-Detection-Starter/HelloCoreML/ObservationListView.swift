//
//  ObservationListView.swift
//  HelloCoreML
//
//  Created by Mohammad Azam on 6/2/23.
//

import SwiftUI

struct ObservationListView: View {
    
    let observations: [Observation]
    
    var body: some View {
        List(observations, id: \.label) { observation in
            HStack {
                Text(observation.label)
                Spacer()
                Text("\(observation.confidence)")
            }
        }
    }
}

struct ObservationListView_Previews: PreviewProvider {
    static var previews: some View {
        ObservationListView(observations: [])
    }
}
